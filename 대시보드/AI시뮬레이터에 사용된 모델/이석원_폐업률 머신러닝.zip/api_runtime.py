from pathlib import Path
import json

DISTRICT_ALIASES = {
    '강서':'강서구','금정':'금정구','기장':'기장군','남':'남구',
    '동':'동구','동래':'동래구','부산진':'부산진구','북':'북구',
    '사상':'사상구','사하':'사하구','서':'서구','수영':'수영구',
    '연제':'연제구','영도':'영도구','중':'중구','해운대':'해운대구'
}

class BusanForecastRuntime:
    def __init__(self, bundle_path):
        self.bundle_path = Path(bundle_path)
        with self.bundle_path.open('r', encoding='utf-8') as f:
            self.data = json.load(f)

        if self.data.get('schema_version') != '4.0.0':
            raise ValueError('지원하지 않는 api_bundle schema_version')

        self.districts = sorted(self.data['annual_forecast'].keys())

    def normalize_district(self, district):
        if not isinstance(district, str) or not district.strip():
            raise ValueError('district는 비어 있지 않은 문자열이어야 합니다.')

        d = district.strip()

        if d in self.districts:
            return d

        if d in DISTRICT_ALIASES and DISTRICT_ALIASES[d] in self.districts:
            return DISTRICT_ALIASES[d]

        for suffix in ('구','군'):
            if d + suffix in self.districts:
                return d + suffix

        raise ValueError(f'지원하지 않는 구·군: {district}')

    def get_forecast(self, district, year=2030):
        d = self.normalize_district(district)

        try:
            y = str(int(year))
        except Exception as e:
            raise ValueError('year는 2026~2030 정수여야 합니다.') from e

        if y not in self.data['annual_forecast'][d]:
            raise ValueError('지원 연도는 2026~2030입니다.')

        return {
            '구군': d,
            '연도': int(y),
            '장기검증': self.data['metadata']['annual_long_validation'],
            **self.data['annual_forecast'][d][y]
        }

    def get_model_info(self, target=None):
        info = self.data['metadata']['annual_long_validation']

        if target is None:
            return info

        if target not in info:
            raise ValueError('target은 폐업, 신규, 가동 중 하나여야 합니다.')

        return info[target]

    def get_risk(self, district):
        d = self.normalize_district(district)
        return {'구군': d, **self.data['risk_2030'][d]}

    def simulate_shock(
        self,
        district,
        year=2030,
        closure_change_pct=0,
        new_change_pct=0,
        active_change_pct=0
    ):
        base = self.get_forecast(district, year)

        converted = []
        for name, value in [
            ('closure_change_pct', closure_change_pct),
            ('new_change_pct', new_change_pct),
            ('active_change_pct', active_change_pct)
        ]:
            try:
                f = float(value)
            except Exception as e:
                raise ValueError(f'{name}는 숫자여야 합니다.') from e

            if f < -100 or f > 1000:
                raise ValueError(f'{name}는 -100% 이상 1000% 이하만 지원합니다.')

            converted.append(f)

        cchg, nchg, achg = converted

        closure = max(0.0, base['폐업'] * (1 + cchg / 100))
        new = max(0.0, base['신규'] * (1 + nchg / 100))
        active = max(0.0, base['가동'] * (1 + achg / 100))

        return {
            '구군': base['구군'],
            '연도': base['연도'],
            '기준예측': {
                '폐업': base['폐업'],
                '신규': base['신규'],
                '가동': base['가동']
            },
            '적용충격_pct': {
                '폐업': cchg,
                '신규': nchg,
                '가동': achg
            },
            '시나리오': {
                '폐업': closure,
                '신규': new,
                '가동': active,
                '폐업부담률': closure / active * 100 if active else None,
                '신규대비폐업비율': closure / new * 100 if new else None,
                '순증감': new - closure
            },
            '주의': (
                '사용자 지정 충격률을 기준예측에 적용한 What-if이며 '
                '사건 발생확률 또는 인과효과 추정이 아닙니다.'
            )
        }

    def replacement_candidates(self, source_district, top_n=5):
        d = self.normalize_district(source_district)

        try:
            n = int(top_n)
        except Exception as e:
            raise ValueError('top_n은 정수여야 합니다.') from e

        if n < 1 or n > 15:
            raise ValueError('top_n은 1~15만 지원합니다.')

        return {
            '기능상실가정지역': d,
            '후보': self.data['replacement_rankings'][d][:n],
            '주의': (
                '실제 재난 후 이동량/성장확률이 아니라 '
                '현재 데이터 기반 대체 후보 상대순위입니다.'
            )
        }
