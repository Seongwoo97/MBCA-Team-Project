from api_runtime import BusanForecastRuntime

rt = BusanForecastRuntime("api_bundle.json")

print(rt.get_forecast("해운대", 2030))
print(rt.get_model_info("폐업"))
print(rt.get_risk("부산진구"))
print(rt.simulate_shock("부산진구", 2030, new_change_pct=-20))
print(rt.replacement_candidates("해운대구", 5))
